import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import java.math.BigDecimal;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
public class CleanMapper extends Mapper<LongWritable, Text, Text, Text> {
 private static final int MISSING = 9999;
 
 @Override
 public void map(LongWritable key, Text value, Context context)
 throws IOException, InterruptedException {
          String line = value.toString();
        	String[] ar = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");
         if (line.contains("GameID") || line.contains("TotalHours") || line.contains("?"))
                return;
         else
  	        context.write(new Text(line), new Text(""));
         }
    

}